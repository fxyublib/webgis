//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by regsvr.rc
//
// This is a part of the Microsoft Foundation Classes C++ library.
// Copyright (c) Microsoft Corporation.  All rights reserved.
//
// This source code is only intended as a supplement to the
// Microsoft Foundation Classes Reference and the
// Books Online documentation provided with the library.
// See these sources for detailed information regarding the
// Microsoft Foundation Classes product.

#define IDS_USAGE                       1
#define IDS_UNRECOGNIZEDFLAG            2
#define IDS_EXTRAARGUMENT               3
#define IDS_NOPROJECT                   4
#define IDS_NODLLNAME                   5
#define IDS_OLEINITFAILED               6
#define IDS_LOADLIBFAILED               7
#define IDS_NOTDLLOROCX                 8
#define IDS_NOENTRYPOINT                9
#define IDS_CALLFAILED                  10
#define IDS_CALLSUCCEEDED               11

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        101
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
